import express from 'express';
const app = express();
const port = 3000;

app.get("/", (req, res)=>{
    const todat= new Date();
    const day = todat.getDay();
    console.log(day);

    let type = "a weekday";
    let adv = "its time to work hard";

    if(day === 0 || day === 6 ){
        type = "the weekwnd";
        adv = "its time to have some fun";
    }
    res.render("index.ejs", {dayType: type, advice: adv})
})

app.listen(3000, ()=>{
    console.log(`Server is running on`);
})